<?php
return array(
    //'配置项'=>'配置值'
    'DEFAULT_MODULE' =>  'WB_Home',  // 默认模块
    "DB_NAME"=>'weibod',
    "DB_USER"=>'aochuan',//'sql_second',
    "DB_PWD"=>'a19920806',//'123456',
    "DB_PREFIX"=>'wbd_',
    'DB_HOST'=>'127.0.0.1',//'211.149.219.235',
    'DB_TYPE'=>'mysql',
    'URL_HTML_SUFFIX'=>'',
    'VAR_SESSION_ID'=>'PHPSESSID',
);