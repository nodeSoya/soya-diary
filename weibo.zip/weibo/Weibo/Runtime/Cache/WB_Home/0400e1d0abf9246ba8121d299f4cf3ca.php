<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-Control" content="no-cache, must-revalidate">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
    <title>微博营销罗盘</title>
    <link rel="stylesheet" type="text/css" href="/weibo/Weibo/Wb_Home/Public/Css/common.css?v=2" />
    <link rel="stylesheet" type="text/css" href="/weibo/Weibo/Wb_Home/Public/Css/main.css?v=<?php echo ($version); ?>" />
    <script src="/weibo/Weibo/Wb_Home/Public/Js/zepto.min.js" ></script>
    <script src="/weibo/Weibo/Wb_Home/Public/Js/zepto-animate.js" ></script>
    <script src="/weibo/Weibo/Wb_Home/Public/Js/zepto-touch.js" ></script>
    <script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
    <script type="text/javascript">
        <?php echo ($wx_config); ?>
    </script>
    <script src="/weibo/Weibo/Wb_Home/Public/Js/wx_share.js?v=11"></script>
    <script>
        //		设置loading进度条
        var loading_line="";
        var loading_circle="";
        var loading_word="";
        function loading(place){
            if(loading_circle=="")
            {
                loading_line=$("#loading_line");
                loading_circle=$("#loading_circle");
                loading_word=$("#loading_word")
            }
            var width=place*2;
            loading_line.animate({borderRightWidth:width+"px"},50);
            loading_circle.animate({left:place+"%"},50);
            loading_word.html(place+"%")
        }
    </script>
</head>
<body>

<!--加载页-->
<section class="page page1" style="display:block;">
    <!--logo-->
    <img class="loading_logo" src="/weibo/Weibo/WB_Home/Public/Images/loading_logo.png" />
    <div class="loading_area">
        <div id="loading_line" class="loading_line"></div>
        <div id="loading_circle" class="loading_circle"></div>
        <div class="loading_word"><span id="loading_word">0%</span></div>
    </div>
</section>
<script>
    loading(10);
</script>
<!--引导页-->
<section class="page page2" style="display:none;">
    <img class="page2_w1" src="/weibo/Weibo/WB_Home/Public/Images/page2_w1.png" />
    <img class="page2_w2" src="/weibo/Weibo/WB_Home/Public/Images/page2_w2.png" />
    <audio id="music" loop="" src="/weibo/Weibo/WB_Home/Public/Static/weibo.mp3"></audio>
    <img onClick="play();" class="music_logo" src="/weibo/Weibo/WB_Home/Public/Images/music.gif" />
    <img  class="page2_up_tip" src="/weibo/Weibo/WB_Home/Public/Images/up_tip.png"  />
</section>
<!--罗盘转动初始页-->
<section class="page page3" style="display: none;">
    <div class="page3_content">
        <img class="page3_pot" src="/weibo/Weibo/WB_Home/Public/Images/page3_pot.png" />
    </div>
    <img class="page3_w1"  src="/weibo/Weibo/WB_Home/Public/Images/page3_w1.png" />
    <img class="page3_w2"  src="/weibo/Weibo/WB_Home/Public/Images/page3_w2.png" />
    <img class="page3_w3"  src="/weibo/Weibo/WB_Home/Public/Images/page3_w3.png" />
    <img class="page3_w4"   src="/weibo/Weibo/WB_Home/Public/Images/page3_w4.png" />
    <img class="page3_w5"  src="/weibo/Weibo/WB_Home/Public/Images/page3_w5.png" />
    <img onClick="toPage4();" class="page3_btn"  src="/weibo/Weibo/WB_Home/Public/Images/page3_btn.png" />
</section>
<script>
    loading(20);
</script>
<!--罗盘核心页-->
<section class="page page4" style="display: none;">
    <img class="page4_bg" src="/weibo/Weibo/WB_Home/Public/Images/page4_bg.png" />
    <img class="page4_bg1"  src="/weibo/Weibo/WB_Home/Public/Images/page4_bg1.png" />
    <!--初始动画底部字-->
    <img class="page4_pw1" src="/weibo/Weibo/WB_Home/Public/Images/page4_pw1.png" />
    <img class="page4_c1_bottoms" src="/weibo/Weibo/WB_Home/Public/Images/page4_c1_bottoms.png" />
    <!--第一个圈-->
    <div id="page4_circle1" class="page4_circle1">
        <img class="page_center_l" src="/weibo/Weibo/WB_Home/Public/Images/page4_center_l.png" />
        <img class="page4_circle1_img" src="/weibo/Weibo/WB_Home/Public/Images/page4_circle1.png" />
        <!--指针-->
        <img id="page4_c1_p" class="page4_c1_p" src="/weibo/Weibo/WB_Home/Public/Images/point1.png" />
        <!--四个区域的按钮-->
        <div>
            <div class="p4c1_btn p4c1_btn1"></div>
            <div class="p4c1_btn p4c1_btn2"></div>
            <div class="p4c1_btn p4c1_btn3"></div>
            <div class="p4c1_btn p4c1_btn4"></div>
        </div>
        <div>
            <img id="p4c1_img0" class="p4c1_img p4c1_img1" src="/weibo/Weibo/WB_Home/Public/Images/page4_c1_li0.png" />
            <img id="p4c1_img1"  class="p4c1_img p4c1_img2" src="/weibo/Weibo/WB_Home/Public/Images/page4_c1_li1.png" />
            <img id="p4c1_img2"  class="p4c1_img p4c1_img3" src="/weibo/Weibo/WB_Home/Public/Images/page4_c1_li2.png" />
            <img id="p4c1_img3"  class="p4c1_img p4c1_img4" src="/weibo/Weibo/WB_Home/Public/Images/page4_c1_li3.png" />
        </div>
    </div>
    <!--圆圈区域-->
    <div id="circle_area" class="circle_area">
        <script>
            loading(30);
        </script>
        <!--第二个圈-->
        <div id="page4_circle2" class="page4_circle2">
            <div id="page4_circle_wa" style="display: none;" >
                <img class="page4_c2_lb" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_lb.png" />
                <img class="page4_c2_lt" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_lt.png" />
                <img class="page4_c2_rb" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_rb.png" />
                <img class="page4_c2_rt" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_rt.png" />
            </div>
            <!--四个区域的大图标-->
            <div id="page4_circle2_bm">
                <div class="page4_c2_bm0">
                    <img class="page4_c2_w01" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_w01.png" />
                    <img class="page4_c2_w02" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_w02.png" />
                </div>
                <div class="page4_c2_bm1">
                    <img class="page4_c2_w11" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_w11.png" />
                    <img class="page4_c2_w12" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_w12.png" />
                </div>
                <div class="page4_c2_bm2">
                    <img class="page4_c2_w21" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_w21.png" />
                    <img class="page4_c2_w221" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_w221.png" />
                    <img class="page4_c2_w222" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_w222.png" />
                </div>
                <div class="page4_c2_bm3">
                    <img class="page4_c2_w31" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_w31.png" />
                    <img class="page4_c2_w32" src="/weibo/Weibo/WB_Home/Public/Images/page4_c2_w32.png" />
                </div>
            </div>
            <img class="page4_circle2_img" src="/weibo/Weibo/WB_Home/Public/Images/page4_circle2.png" />
        </div>
        <script>
            loading(50);
        </script>
        <!--第三个圈-->
        <div id="page4_circle3" class="page4_circle3" >
            <!--四个区域的大图标-->
            <div id="page4_circle3_bm">
                <img style="display: none;" class="page4_c3_bm0" src="/weibo/Weibo/WB_Home/Public/Images/page4_c3_bm0.png" />
                <img style="display: none;" class="page4_c3_bm1" src="/weibo/Weibo/WB_Home/Public/Images/page4_c3_bm1.png" />
                <img style="display: none;" class="page4_c3_bm2" src="/weibo/Weibo/WB_Home/Public/Images/page4_c3_bm2.png" />
                <img style="display: none;" class="page4_c3_bm3" src="/weibo/Weibo/WB_Home/Public/Images/page4_c3_bm3.png" />
            </div>
            <img class="page4_circle3_img" src="/weibo/Weibo/WB_Home/Public/Images/page4_circle3.png" />
        </div>
        <script>
            loading(60);
        </script>
        <!--第四个圈-->
        <div id="page4_circle4" class="page4_circle4">
            <!--亮灯集合-->
            <div id="page4_c4_gl">
                <img  class="page4_bl0" src="/weibo/Weibo/WB_Home/Public/Images/page4_bl0.png"  />
                <img class="page4_bl1" src="/weibo/Weibo/WB_Home/Public/Images/page4_bl1.png"  />
                <img class="page4_bl2" src="/weibo/Weibo/WB_Home/Public/Images/page4_bl2.png"  />
                <img class="page4_bl3" src="/weibo/Weibo/WB_Home/Public/Images/page4_bl3.png"  />
                <img class="page4_bl4" src="/weibo/Weibo/WB_Home/Public/Images/page4_bl4.png"  />
                <img class="page4_bl5" src="/weibo/Weibo/WB_Home/Public/Images/page4_bl5.png"  />
                <img class="page4_bl6" src="/weibo/Weibo/WB_Home/Public/Images/page4_bl6.png"  />
                <img class="page4_bl7" src="/weibo/Weibo/WB_Home/Public/Images/page4_bl7.png"  />
                <img class="page4_bl8" src="/weibo/Weibo/WB_Home/Public/Images/page4_bl8.png"  />
                <img class="page4_bl9" src="/weibo/Weibo/WB_Home/Public/Images/page4_bl9.png"  />
            </div>
            <script>
                loading(70);
            </script>
            <!--内容集合-->
            <div id="page4_c4_cj" style="display: none;">
                <img class="page4_lw0" src="/weibo/Weibo/WB_Home/Public/Images/page4_lw0.png"  />
                <img class="page4_lw1" src="/weibo/Weibo/WB_Home/Public/Images/page4_lw1.png"  />
                <img class="page4_lw2" src="/weibo/Weibo/WB_Home/Public/Images/page4_lw2.png"  />
                <img class="page4_lw3" src="/weibo/Weibo/WB_Home/Public/Images/page4_lw3.png"  />
                <img class="page4_lw4" src="/weibo/Weibo/WB_Home/Public/Images/page4_lw4.png"  />
                <img class="page4_lw5" src="/weibo/Weibo/WB_Home/Public/Images/page4_lw5.png"  />
                <img class="page4_lw6" src="/weibo/Weibo/WB_Home/Public/Images/page4_lw6.png"  />
                <img class="page4_lw7" src="/weibo/Weibo/WB_Home/Public/Images/page4_lw7.png"  />
                <img class="page4_lw8" src="/weibo/Weibo/WB_Home/Public/Images/page4_lw8.png"  />
                <img class="page4_lw9" src="/weibo/Weibo/WB_Home/Public/Images/page4_lw9.png"  />
            </div>
            <!--大图对于内容集合-->
            <div id="page4_c4_bm">
                <img style="display: none;" class="page4_c4_bm0" src="/weibo/Weibo/WB_Home/Public/Images/page4_c4_bm0.png"  />
                <img style="display: none;" class="page4_c4_bm1" src="/weibo/Weibo/WB_Home/Public/Images/page4_c4_bm1.png"  />
                <img style="display: none;" class="page4_c4_bm2" src="/weibo/Weibo/WB_Home/Public/Images/page4_c4_bm2.png"  />
                <img style="display: none;" class="page4_c4_bm3" src="/weibo/Weibo/WB_Home/Public/Images/page4_c4_bm3.png"  />
                <img style="display: none;" class="page4_c4_bm4" src="/weibo/Weibo/WB_Home/Public/Images/page4_c4_bm4.png"  />
                <img style="display: none;" class="page4_c4_bm5" src="/weibo/Weibo/WB_Home/Public/Images/page4_c4_bm5.png"  />
                <img style="display: none;" class="page4_c4_bm6" src="/weibo/Weibo/WB_Home/Public/Images/page4_c4_bm6.png"  />
                <img style="display: none;" class="page4_c4_bm7" src="/weibo/Weibo/WB_Home/Public/Images/page4_c4_bm7.png"  />
                <img style="display: none;" class="page4_c4_bm8" src="/weibo/Weibo/WB_Home/Public/Images/page4_c4_bm8.png"  />
                <img style="display: none;" class="page4_c4_bm9" src="/weibo/Weibo/WB_Home/Public/Images/page4_c4_bm9.png"  />
            </div>
            <img class="page4_circle4_img" src="/weibo/Weibo/WB_Home/Public/Images/page4_circle4.png" />
        </div>
        <script>
            loading(80);
        </script>
        <!--第五个圆-->
        <div id="page4_circle5" class="page4_circle5" >
            <!--亮灯集合-->
            <div id="page4_c5_gl">
                <img  class="page4_c5_bl0" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_bl0.png"  />
                <img  class="page4_c5_bl1" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_bl1.png"  />
                <img  class="page4_c5_bl2" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_bl2.png"  />
                <img  class="page4_c5_bl3" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_bl3.png"  />
                <img  class="page4_c5_bl4" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_bl4.png"  />
                <img  class="page4_c5_bl5" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_bl5.png"  />
                <img  class="page4_c5_bl6" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_bl6.png"  />
                <img  class="page4_c5_bl7" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_bl7.png"  />
                <img  class="page4_c5_bl8" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_bl8.png"  />
                <img  class="page4_c5_bl9" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_bl9.png"  />
            </div>
            <!--内容集合-->
            <div id="page4_c5_lw">
                <img  class="page4_c5_lw0" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_lw0.png"  />
                <img class="page4_c5_lw1" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_lw1.png"  />
                <img class="page4_c5_lw2" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_lw2.png"  />
                <img class="page4_c5_lw3" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_lw3.png"  />
                <img class="page4_c5_lw4" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_lw4.png"  />
                <img class="page4_c5_lw5" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_lw5.png"  />
                <img class="page4_c5_lw6" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_lw6.png"  />
                <img class="page4_c5_lw7" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_lw7.png"  />
                <img class="page4_c5_lw8" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_lw8.png"  />
                <img class="page4_c5_lw9" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_lw9.png"  />
            </div>
            <img class="page4_circle5_img" src="/weibo/Weibo/WB_Home/Public/Images/page4_circle5.png" />
            <img id="page4_c5_cho0" class="page4_circle5_cho" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_cho0.png" />
            <img id="page4_c5_cho1" class="page4_circle5_cho" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_cho1.png" />
            <img id="page4_c5_cho2" class="page4_circle5_cho" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_cho2.png" />
            <img id="page4_c5_cho3" class="page4_circle5_cho" src="/weibo/Weibo/WB_Home/Public/Images/page4_c5_cho3.png" />
        </div>
    </div>
    <!--最后的两个按钮-->
    <div id="page4_lt_btn"  style="display: none;">
        <img onClick="backSearch()" class="page4_lt_btn1" src="/weibo/Weibo/WB_Home/Public/Images/page4_lt_btn1.png"  />
        <img onClick="getGather();" class="page4_lt_btn2" src="/weibo/Weibo/WB_Home/Public/Images/page4_lt_btn2.png"  />
    </div>
    <!--认证前页按钮-->
    <div class="page4_gtw_box" style="display: none;">
        <img class="page4_gtw" src="/weibo/Weibo/WB_Home/Public/Images/page4_gtw.png" />
        <img onClick="toPage5();" class="page4_gtw_btn" src="/weibo/Weibo/WB_Home/Public/Images/page4_gtw_btn.png" />
    </div>
</section>
<script>
    loading(90);
</script>
<!--表单提交页-->
<section class="page page5" style="display: none;">
    <!--中间内容部分-->
    <div class="page5_content">
        <!--认证表单提交-->
        <div id="page5_content1" style="display: block;">
            <img class="page5_ct_topw1" src="/weibo/Weibo/WB_Home/Public/Images/page5_ct_topw1.png" />
            <div class="p5_input_box">
                <div class="p5_input_box0">
                    <img class="p5_input_l0" src="/weibo/Weibo/WB_Home/Public/Images/p5_input_l0.png" />
                    <input class="p5_input0" type="text" name="name" value=""  />
                </div>
                <div class="p5_input_box1">
                    <img class="p5_input_l0" src="/weibo/Weibo/WB_Home/Public/Images/p5_input_l1.png" />
                    <input class="p5_input0" type="text" name="phone" value=""  />
                </div>
                <div class="p5_input_box2">
                    <img class="p5_input_l1" src="/weibo/Weibo/WB_Home/Public/Images/p5_input_l3.png" />
                    <input class="p5_input0" type="text" name="email" value=""  />
                </div>
                <div class="p5_input_box3">
                    <img class="p5_input_l0" src="/weibo/Weibo/WB_Home/Public/Images/p5_input_l2.png" />
                    <input class="p5_input0" type="text" name="daili" value=""  />
                </div>
            </div>
            <img onClick="sendMsg();" src="/weibo/Weibo/WB_Home/Public/Images/page5_ct_btn.png" class="page5_ct_btn" />
        </div>
        <!--认证成功后-->
        <div id="page5_content2" style="display: none;">
            <img class="page5_ct2_topw1" src="/weibo/Weibo/WB_Home/Public/Images/page5_ct2_topw1.png" />
            <img class="page5_ct2_qrcode" src="/weibo/Weibo/WB_Home/Public/Images/page5_ct2_qrcode.png" />
            <img class="page5_ct2_topw2" src="/weibo/Weibo/WB_Home/Public/Images/page5_ct2_topw2.png" />
        </div>
    </div>
    <!--认证后的底部按钮-->
    <div class="page5_bottom_btn" style="display: none;">
        <div class="p5backsearch" onClick="p5backsearch();"></div>
        <div class="showShare" onClick="$('#shareBox').show()"></div>
        <img class="page5_bottom_img" src="/weibo/Weibo/WB_Home/Public/Images/page5_bottom_btn.png"  />
    </div>
</section>
<!--分享蒙版-->
<div style="display: none;" onClick="$('#shareBox').hide()" class="shareBox" id="shareBox">
    <div class="share_content">
        <div class="share_circle_box">
            <img class="share_circle" src="/weibo/Weibo/WB_Home/Public/Images/share_circle.png" />
            <img class="share_circle_pot" src="/weibo/Weibo/WB_Home/Public/Images/page3_pot.png"  />
        </div>
        <div class="share_word" style="text-align:center;">呼唤伙伴一起加入<br>微博营销联盟吧！</div>
    </div>
</div>
<script>
    var screen_H,screen_W;//屏幕的高度和宽度
    var light_list=[0,0,0,0,0,0,0,0,0,0];
    var has_choosed=[0,0,0,0];
    var old_choose_place=-1,new_choose_place=-1,old_choose=-1;//选择的区域
    var shake_word;//闪频记时
    var isstop=0;
    $(function(){
        document.addEventListener('touchmove', function (event) {
            event.preventDefault();
        }, false);
        screen_W=(window.innerWidth>0)?window.innerWidth:screen.width;
        screen_H=(window.innerHeight>0)?window.innerHeight:screen.height;
        $("body").css("width",screen_W);
        $("body").css("height",screen_H);
//				计算第三页指针应该的高度
        var pot_weight=screen_H*0.56;
        var pot_left=screen_W-0.28*screen_H;
        $(".page3_pot").css("left",pot_left);
        //圆圈区域的宽度
        var area_l=screen_W*4;
        var circle_area=$("#circle_area");
        circle_area.css("width",area_l);
        circle_area.css("height",area_l);
        circle_area.css("left",-screen_W*1.5);
//				刚刚开始时圆圈所在的位置
        var ck_top=screen_H*0.49-area_l/2;
        var p4c1_top=screen_H*0.49-0.25*screen_W;
        var p4c1=$("#page4_circle1");
        p4c1.css("height",0.5*screen_W);
        p4c1.css("top",p4c1_top);
        $("#circle_area").css("top",ck_top);
        //所有内容加载完成后执行片段
        loading(100);
        setTimeout(function(){
            $(".page1").hide();
            $(".page2").show();
//					播放音乐
            play();
            $(".music_logo").addClass("music_pl");
            setTimeout(function(){
                $(".page2_w1").addClass("show_slow");
                setTimeout(function(){
                    $(".page2_w2").addClass("show_slow");
                    $(".page2").bind("swipe_up");
//						toPage3();
                    $(".page2").swipeUp(function(){
                        toPage3();
                    })
//                  第三页向左滑
                    $(".page3").swipeLeft(function(){
                        page3ToRight();
                    })
//                   第三页向右滑
                    $(".page3").swipeRight(function(){
                        page3ToLeft();
                    })
                },1200)
            },1000)

        },1500);
        bind_p4c1_btn();
    })
    //			音乐播放
    function play(){
        var music=document.getElementById("music");
        var music_logo=$(".music_logo");
        if(music.paused){
            music.play();
            music_logo.addClass("music_pl");
        }else{
            music.pause();
            music_logo.removeClass("music_pl");
        }
    }
    var isright=-1;
    //			从第二页跳到第三页
    function toPage3(){
        var page3=$(".page3");
        page3.show();
        page3.animate({"opacity":"1"},1000,function(){
            setTimeout(function(){
                $(".page2").hide();
                page3_animate();
            },1000)
        })
    }

    //  向右滑
    function page3ToRight(){
        if(isright!=0){
            return;
        }
        $(".page3_w4").css("display","none");
        $(".page3_w5").css("display","none");
//      $(".page3_btn").css("display","none");
        $(".page3_content").animate({translate3d: '0%,0,0'},1000,function(){
            $(".page3_w1").css("display","inline");
            $(".page3_w2").css("display","inline");
            $(".page3_w3").css("display","inline");
            isright=1;
        })
    }
    //  向左滑
    function page3ToLeft(){
        if(isright!=1){
            return;
        }
        $(".page3_w1").css("display","none");
        $(".page3_w2").css("display","none");
        $(".page3_w3").css("display","none");
        $(".page3_content").animate({translate3d: '50%,0,0'},1000,function(){
            $(".page3_w4").css("display","inline");
            $(".page3_w5").css("display","inline");
//                  $(".page3_btn").css("display","inline");
            isright=0;
        })
    }
    //			从第三页跳到第四页
    function toPage4(){
        var page4=$(".page4");
        var page3_content=$(".page3_content");
        $(".page3_w1").hide();
        $(".page3_w2").hide();
        $(".page3_w3").hide();
        $(".page3_w4").hide();
        $(".page3_w5").hide();
        $(".page3_btn").hide();
        $(".page3_pot").hide();
        if(isright==1){
            page3_content.animate({translate3d: '25%,0,0',scale:1},1000,function(){
                page3_content.animate({translate3d:'25%,0,0',scale:2},1000);
            });
        }else{
            page3_content.addClass("page3_ct_animate1");
        }
        setTimeout(function(){
            page4.show();
            page4.animate({"opacity":"1"},1000,function(){
                shakeP4C1Icon();
                setTimeout(function(){
                    $(".page3").hide();
                },500)
            })
        },2100)
    }
    //闪一下四个亮光
    function shakeP4C1Icon(){
        $("#p4c1_img0").animate({"opacity":1},500,function(){
            $("#p4c1_img1").animate({"opacity":1},500,function(){
                $("#p4c1_img2").animate({"opacity":1},500,function(){
                    $("#p4c1_img3").animate({"opacity":1},500,function(){
                        setTimeout(function(){
                            $("#p4c1_img0").animate({"opacity":0});
                            $("#p4c1_img1").animate({"opacity":0});
                            $("#p4c1_img2").animate({"opacity":0});
                            $("#p4c1_img3").animate({"opacity":0});
                            if(old_choose!=-1){
                                $("#p4c1_img"+old_choose).animate({"opacity":1});
                            }
                        },500)
                    });
                });
            });
        });
    }
    //			从第四页跳到第五页
    function toPage5(){
        var page5=$(".page5");
        page5.show();
        page5.animate({"translate":"0,-100%"},1000,function(){
            setTimeout(function(){
                $(".page4").hide();
            },1000)
        })
    }
    //			第三页的动画
    function page3_animate(){
        $(".page3_pot").addClass("page3_pot_rotate");
        $(".page3_w1").animate({"opacity":1},2000,function(){
            $(".page3_w2").animate({"opacity":1},2000,function(){
                $(".page3_w3").animate({"opacity":1},2000,function(){
                    $(".page3_w1").css("display","none");
                    $(".page3_w2").css("display","none");
                    $(".page3_w3").css("display","none");
                    $(".page3_content").animate({translate3d: '50%,0,0'},1500,function(){
                        setTimeout(function(){
                            $(".page3_w5").animate({"opacity":1},2000,function(){
                                $(".page3_w4").animate({"opacity":1},2000,function(){
                                    $(".page3_btn").animate({"opacity":1},1000,function(){
                                        isright=0;
                                    })
                                })
                            })
                        },500)
                    })
                });
            });
        });
    }
    //绑定四块区域按钮
    function bind_p4c1_btn(){
        var p4c1_btn=$(".p4c1_btn");
        for(var i=0;i<4;i++){
            p4c1_btn[i].setAttribute("onclick","chooseArea("+i+")");
        }
    }
    //			解绑四块区域
    function unbind_p4c1_btn(){
        var p4c1_btn=$(".p4c1_btn");
        for(var i=0;i<4;i++){
            p4c1_btn[i].removeAttribute("onclick");
        }
    }
    //  绑定第一个圆让其可以点击立即返回到原来的页面
    function bindp4c1_back(){
        var p4c1=$("#page4_circle1");
        p4c1.unbind();
        setTimeout(function(){
            p4c1.bind("click",function(){
                isstop=1;
            })
        },500)
    }
    //  绑定中心圆的位置点击可返回
    function bindp4c1_back1(){
        var p4c1=$("#page4_circle1");
        p4c1.unbind();
        setTimeout(function(){
            p4c1.bind("click",function(){
                $("#page4_circle1").unbind();
                backSearch();
            })
        },500)
    }
    //	停止动画返回到最初的界面
    function checkStopAnimate(){
        if(isstop==1){
            isstop=0;
            $("#page4_circle1").unbind();
            backSearch();
            throw SyntaxError("为停止所有动画所抛出的异常；");
        }
    }
    //选择区域后位置变化
    function chooseArea(type){
        $("#p4c1_img"+type).animate({"opacity":1});
        unbind_p4c1_btn();
        bindp4c1_back();
        $(".page4_pw1").hide();
        $(".page4_c1_bottoms").hide();
        new_choose_place=type;
        old_choose=type;
        has_choosed[type]=1;
        var page4_c1_p=$("#page4_c1_p");
        var circle_area=$("#circle_area");
        var page4_circle1=$("#page4_circle1");
        var ca_width=4*screen_W;
        var ca_left=-1.5*screen_W;
        if(type==0){
            var ca_left_plus=screen_W*0.35;
            var ca_top=screen_H-ca_width*0.5-screen_W*0.5*0.6*0.5;
            ca_left=ca_left-ca_left_plus;
            page4_c1_p.attr("class","page4_c1_p0")
            var p4c1_top=0.51*screen_H-0.15*screen_W;
            var p4c1_left=-0.35*screen_W;
        }else if(type==1){
            var ca_left_plus=screen_W*0.35;
            var ca_top=-ca_width*0.4625;
            ca_left=ca_left-ca_left_plus;
            var p4c1_top=-(0.49*screen_H-0.15*screen_W);
            var p4c1_left=-0.35*screen_W;
            page4_c1_p.attr("class","page4_c1_p1")
        }else if(type==2){
            var ca_left_plus=screen_W*0.35;
            var ca_top=-ca_width*0.4625;
            ca_left=ca_left+ca_left_plus;
            page4_c1_p.attr("class","page4_c1_p2");
            var p4c1_top=-(0.49*screen_H-0.15*screen_W);
            var p4c1_left=0.35*screen_W;
        }else{
            var ca_left_plus=screen_W*0.35;
            var ca_top=screen_H-ca_width*0.5-screen_W*0.5*0.6*0.5;
            ca_left=ca_left+ca_left_plus;
            page4_c1_p.attr("class","page4_c1_p3");
            var p4c1_top=0.51*screen_H-0.15*screen_W;
            var p4c1_left=0.35*screen_W;
        }
        $(".page4_bg1").css("display","none");
        circle_area.css("left",ca_left);
        circle_area.css("top",ca_top);
        page4_circle1.animate({"scale":0.6},1000,function(){
            checkStopAnimate();
            page4_circle1.animate({"translate3d":p4c1_left+"px,"+p4c1_top+"px,"+"0","scale":0.6},1000,function(){
                checkStopAnimate();
                //显示四个圆
                $("#page4_circle2").animate({"opacity":1});
                $("#page4_circle3").animate({"opacity":1});
                var page4_c2_bm=$(".page4_c2_bm"+type);
                setTimeout(function(){
                    checkStopAnimate();
                    page4_c2_bm.show();
                    page4_c2_bm.animate({"opacity":1});
                    setTimeout(function(){
                        page4_c2_bm.hide();
                        checkStopAnimate();
                        small_step2(type);
                    },2500)
                },1500)
            })
        })

    }
    //缩小第二个罗盘
    function small_step2(type){
        checkStopAnimate();
        $("#page4_circle4").show();
        $("#page4_circle5").show();
        $("#page4_circle2").animate({"scale":0.25},1000,function(){
            checkStopAnimate();
            $("#page4_circle_wa").show();
            if(type==0){
                $(".page4_c2_rt").show();
            }else if(type==1){
                $(".page4_c2_rb").show();
            }else if(type==2){
                $(".page4_c2_lb").show();
            }else{
                $(".page4_c2_lt").show();
            }
            $("#page4_circle3").animate({"scale":0.6},1000,function(){
                $(".page4_c3_bm"+type).show();
                $(".page4_c3_bm"+type).addClass("show_slow");
                setTimeout(function(){
                    $(".page4_c3_bm"+type).hide();
                    checkStopAnimate();
                    small_step3(type);
                },3500)
            });
        });
    }
    //缩小第三个罗盘
    function small_step3(type){
        checkStopAnimate();
        $("#page4_circle3").animate({"scale":0.17},1000,function(){
            checkStopAnimate();
            $("#page4_circle4").animate({"scale":0.55},1000,function(){
                checkStopAnimate();
                setTimeout(function(){
                    checkStopAnimate();
                    if(type==0){
                        $(".page4_c4_bm0").show("slow");
                        $(".page4_c4_bm1").show("slow");
                    }else if(type==1){
                        $(".page4_c4_bm2").show("slow");
                        $(".page4_c4_bm3").show("slow");
                        $(".page4_c4_bm4").show("slow");
                    }else if(type==2){
                        $(".page4_c4_bm5").show("slow");
                        $(".page4_c4_bm6").show("slow");
                        $(".page4_c4_bm7").show("slow");
                    }else{
                        $(".page4_c4_bm8").show("slow");
                        $(".page4_c4_bm9").show("slow");
                    }
                    setTimeout(function(){
                        checkStopAnimate();
                        small_step4(type);
                    },3500)
                },1000)
            });
        });



    }
    //			缩小第四个罗盘
    function small_step4(type){
        checkStopAnimate();
        if(type==0){
            $(".page4_c4_bm0").hide();
            $(".page4_c4_bm1").hide();
            $("#page4_lt_btn").attr("class","page4_lt_btn00")
        }else if(type==1){
            $(".page4_c4_bm2").hide();
            $(".page4_c4_bm3").hide();
            $(".page4_c4_bm4").hide();
            $("#page4_lt_btn").attr("class","page4_lt_btn11")
        }else if(type==2){
            $(".page4_c4_bm5").hide();
            $(".page4_c4_bm6").hide();
            $(".page4_c4_bm7").hide();
            $("#page4_lt_btn").attr("class","page4_lt_btn22")
        }else{
            $(".page4_c4_bm8").hide();
            $(".page4_c4_bm9").hide();
            $("#page4_lt_btn").attr("class","page4_lt_btn33")
        }
        bind_p4c5bl();
        old_choose_place;
        if(old_choose_place!=-1){
            $("#page4_c5_cho"+old_choose_place).css("opacity",0);
        }
        $("#page4_circle4").animate({"scale":0.23},1000,function(){
            checkStopAnimate();
            if(type==0){
                $(".page4_lw0").addClass("show_slow");
                $(".page4_lw1").addClass("show_slow");
            }else if(type==1){
                $(".page4_lw2").addClass("show_slow");
                $(".page4_lw3").addClass("show_slow");
                $(".page4_lw4").addClass("show_slow");
            }else if(type==2){
                $(".page4_lw5").addClass("show_slow");
                $(".page4_lw6").addClass("show_slow");
                $(".page4_lw7").addClass("show_slow");
            }else{
                $(".page4_lw8").addClass("show_slow");
                $(".page4_lw9").addClass("show_slow");
            }
            $("#page4_c4_cj").show();
            $("#page4_circle5").animate({"scale":0.55},1000,function(){
                checkStopAnimate();
                shakeLight(type);
                if(type==0){
                    $(".page4_c5_lw0").addClass("show_slow");
                    $(".page4_c5_lw1").addClass("show_slow");
                    if(light_list[0]==1){
                        onLight(0);
                    }
                    if(light_list[1]==1){
                        onLight(1);
                    }
                }else if(type==1){
                    $(".page4_c5_lw2").addClass("show_slow");
                    $(".page4_c5_lw3").addClass("show_slow");
                    $(".page4_c5_lw4").addClass("show_slow");
                    if(light_list[2]==1){
                        onLight(2);
                    }
                    if(light_list[3]==1){
                        onLight(3);
                    }
                    if(light_list[4]==1){
                        onLight(4);
                    }
                }else if(type==2){
                    $(".page4_c5_lw5").addClass("show_slow");
                    $(".page4_c5_lw6").addClass("show_slow");
                    $(".page4_c5_lw7").addClass("show_slow");
                    if(light_list[5]==1){
                        onLight(5);
                    }
                    if(light_list[6]==1){
                        onLight(6);
                    }
                    if(light_list[7]==1){
                        onLight(7);
                    }
                }else{
                    $(".page4_c5_lw8").addClass("show_slow");
                    $(".page4_c5_lw9").addClass("show_slow");
                    if(light_list[8]==1){
                        onLight(8);
                    }
                    if(light_list[9]==1){
                        onLight(9);
                    }
                }
                $("#page4_lt_btn").show();
            });
        });
        bindp4c1_back1();
        shakeWord();
        setTimeout(function(){
            shake_word=setInterval("shakeWord()",2000);
        },2000)

    }
    //			闪烁文字
    function shakeWord(){
        $("#page4_c5_cho"+old_choose_place).animate({"opacity":0});
        if(new_choose_place==0){
            $("#page4_c5_cho2").animate({"opacity":1});
            old_choose_place=new_choose_place=2;
        }else if(new_choose_place==1){
            $("#page4_c5_cho3").animate({"opacity":1});
            old_choose_place=new_choose_place=3;
        }else if(new_choose_place==2){
            $("#page4_c5_cho0").animate({"opacity":1});
            old_choose_place=new_choose_place=0;
        }else{
            $("#page4_c5_cho1").animate({"opacity":1});
            old_choose_place=new_choose_place=1;
        }
    }
    //			聚拢每个圆圈
    function getGather(){
        old_choose=-1
        for(var i=0;i<10;i++){
            if(light_list[i]==1){
                $(".page4_bl"+i).css("opacity",1);
                $(".page4_c5_bl"+i).css("opacity",1);
            }
        }
        $("#page4_lt_btn").hide();
        $("#page4_circle5").hide();
        $("#page4_c1_p").attr("class","page4_c1_p");
        $(".page4_bg1").css("display","none");
        $("#page4_circle3").attr("style","");
        $("#page4_circle2").attr("style","");
        $("#page4_circle5").attr("style","");
        $("#page4_circle4").attr("style","");
        window.clearInterval(shake_word);
        var area_l=screen_W*0.9;
        var circle_area=$("#circle_area");
        circle_area.css("width",area_l);
        circle_area.css("height",area_l);
        circle_area.css("left",screen_W*0.05);
        circle_area.css("top",screen_H*0.1);
        var p4c1_top=screen_H*0.1+screen_W*0.45-0.17*screen_W;
        var p4c1=$("#page4_circle1");
        p4c1.attr("style","");
        p4c1.css("height",0.34*screen_W);
        p4c1.css("width",0.34*screen_W);
        p4c1.css("top",p4c1_top);
        p4c1.css("left","33%");
        $("#page4_circle2").attr("class","page4_circle22");
        $("#page4_circle3").attr("class","page4_circle33");
        $("#page4_circle4").attr("class","page4_circle44");
        $(".page4_gtw_box").show();
        $(".page4_c2_rt").show();
        $(".page4_c2_rb").show();
        $(".page4_c2_lt").show();
        $(".page4_c2_lb").show();
        if(has_choosed[0]){
            $(".page4_lw0").addClass("show_slow");
            $(".page4_lw1").addClass("show_slow");
        }
        if(has_choosed[1]){
            $(".page4_lw2").addClass("show_slow");
            $(".page4_lw3").addClass("show_slow");
            $(".page4_lw4").addClass("show_slow");
        }
        if(has_choosed[2]){
            $(".page4_lw5").addClass("show_slow");
            $(".page4_lw6").addClass("show_slow");
            $(".page4_lw7").addClass("show_slow");
        }
        if(has_choosed[3]){
            $(".page4_lw8").addClass("show_slow");
            $(".page4_lw9").addClass("show_slow");
        }
        bind_p4c4bl();
        gtBindCircle();
        shakeP4C1Icon();
    }
    //			认证页面绑定大圆圈，让其可返回选择
    function gtBindCircle(){
        $("#page4_circle1").attr("onclick","backSearch1()");
    }
    //返回认证选择区域页面
    function backSearch1(){
        $("#page4_circle1").attr("onclick","");
        unbind_p4c4bl();
        $(".page4_gtw_box").hide();
        backSearch();
    }
    //			绑定第四个圆上的十个点击事件
    function bind_p4c4bl(){
        var page4_c4_cj=$("#page4_c4_cj").find("img");
        for(var i=0;i<10;i++){
            page4_c4_cj[i].setAttribute("onclick","onShotLight("+i+")");
        }
    }
    //			解绑第四个圆上的十个点击事件
    function unbind_p4c4bl(){
        var page4_c4_cj=$("#page4_c4_cj").find("img");
        for(var i=0;i<10;i++){
            page4_c4_cj[i].removeAttribute("onclick");
        }
    }
    //			绑定第五个圆上的十个点击事件
    function bind_p4c5bl(){
        var page4_c4_cj=$("#page4_c5_lw").find("img");
        for(var i=0;i<10;i++){
            page4_c4_cj[i].setAttribute("onclick","onShotLight("+i+")");
        }
    }
    //			解绑第五个圆上的十个点击事件
    function unbind_p4c5bl(){
        var page4_c4_cj=$("#page4_c5_lw").find("img");
        for(var i=0;i<10;i++){
            page4_c4_cj[i].removeAttribute("onclick");
        }
    }
    //			灯闪下
    function shakeLight(i){
        if(i==0){
            setTimeout(function(){
                $(".page4_bl0").animate({"opacity":1});
                $(".page4_c5_bl0").animate({"opacity":1});
                setTimeout(function(){
                    $(".page4_bl1").animate({"opacity":1});
                    $(".page4_c5_bl1").animate({"opacity":1});
                    setTimeout(function(){
                        $(".page4_bl0").animate({"opacity":0});
                        $(".page4_c5_bl0").animate({"opacity":0});
                        $(".page4_bl1").animate({"opacity":0});
                        $(".page4_c5_bl1").animate({"opacity":0});
                    },1000)
                },500)
            },500)

        }else if(i==1){
            setTimeout(function(){
                $(".page4_bl2").animate({"opacity":1});
                $(".page4_c5_bl2").animate({"opacity":1});
                setTimeout(function(){
                    $(".page4_bl3").animate({"opacity":1});
                    $(".page4_c5_bl3").animate({"opacity":1});
                    setTimeout(function(){
                        $(".page4_bl4").animate({"opacity":1});
                        $(".page4_c5_bl4").animate({"opacity":1});
                        setTimeout(function(){
                            $(".page4_bl2").animate({"opacity":0});
                            $(".page4_c5_bl2").animate({"opacity":0});
                            $(".page4_bl3").animate({"opacity":0});
                            $(".page4_c5_bl3").animate({"opacity":0});
                            $(".page4_bl4").animate({"opacity":0});
                            $(".page4_c5_bl4").animate({"opacity":0});
                        },1000)
                    },500)
                },500)
            },500)
        }else if(i==2){
            setTimeout(function(){
                $(".page4_bl5").animate({"opacity":1});
                $(".page4_c5_bl5").animate({"opacity":1});
                setTimeout(function(){
                    $(".page4_bl6").animate({"opacity":1});
                    $(".page4_c5_bl6").animate({"opacity":1});
                    setTimeout(function(){
                        $(".page4_bl7").animate({"opacity":1});
                        $(".page4_c5_bl7").animate({"opacity":1});
                        setTimeout(function(){
                            $(".page4_bl5").animate({"opacity":0});
                            $(".page4_c5_bl5").animate({"opacity":0});
                            $(".page4_bl6").animate({"opacity":0});
                            $(".page4_c5_bl6").animate({"opacity":0});
                            $(".page4_bl7").animate({"opacity":0});
                            $(".page4_c5_bl7").animate({"opacity":0});
                        },1000)
                    },500)
                },500)
            },500)
        }else{
            setTimeout(function(){
                $(".page4_bl8").animate({"opacity":1});
                $(".page4_c5_bl8").animate({"opacity":1});
                setTimeout(function(){
                    $(".page4_bl9").animate({"opacity":1});
                    $(".page4_c5_bl9").animate({"opacity":1});
                    setTimeout(function(){
                        $(".page4_bl8").animate({"opacity":0});
                        $(".page4_c5_bl8").animate({"opacity":0});
                        $(".page4_bl9").animate({"opacity":0});
                        $(".page4_c5_bl9").animate({"opacity":0});
                    },1000)
                },500)
            },500)
        }
    }
    //			点灯
    function onLight(i){
        $(".page4_bl"+i).css("opacity",1);
        $(".page4_c5_bl"+i).css("opacity",1);
    }
    //			灭灯
    function shotLight(i){
        $(".page4_bl"+i).css("opacity",0);
        $(".page4_c5_bl"+i).css("opacity",0);
    }
    //			点亮或灭灯
    function onShotLight(i){
        if(old_choose!=-1){
            if(old_choose==0){
                if(i!=0&&i!=1){
                    return false;
                }
            }else if(old_choose==1){
                if(i!=2&&i!=3&&i!=4){
                    return false;
                }
            }else if(old_choose==2){
                if(i!=5&&i!=6&&i!=7){
                    return false;
                }
            }else{
                if(i!=8&&i!=9){
                    return false;
                }
            }
        }
        var isshow=$(".page4_lw"+i).css("opacity");
        if(isshow=="1"){
            if(light_list[i]){
                light_list[i]=0;
                $(".page4_bl"+i).css("opacity",0);
                $(".page4_c5_bl"+i).css("opacity",0);
            }else{
                light_list[i]=1;
                $(".page4_bl"+i).css("opacity",1);
                $(".page4_c5_bl"+i).css("opacity",1);
            }
        }
    }
    //			返回探寻其他纬度
    function backSearch(){
        $("#page4_circle1").unbind();
        $(".page4_c2_rt").css("display","none");
        $(".page4_c2_rb").css("display","none");
        $(".page4_c2_lt").css("display","none");
        $(".page4_c2_lb").css("display","none");
            $(".page4_lw0").removeClass("show_slow");
            $(".page4_lw1").removeClass("show_slow");
            $(".page4_c5_lw0").removeClass("show_slow");
            $(".page4_c5_lw1").removeClass("show_slow");
            $(".page4_lw2").removeClass("show_slow");
            $(".page4_lw3").removeClass("show_slow");
            $(".page4_lw4").removeClass("show_slow");
            $(".page4_c5_lw2").removeClass("show_slow");
            $(".page4_c5_lw3").removeClass("show_slow");
            $(".page4_c5_lw4").removeClass("show_slow");
            $(".page4_lw5").removeClass("show_slow");
            $(".page4_lw6").removeClass("show_slow");
            $(".page4_lw7").removeClass("show_slow");
            $(".page4_c5_lw5").removeClass("show_slow");
            $(".page4_c5_lw6").removeClass("show_slow");
            $(".page4_c5_lw7").removeClass("show_slow");
            $(".page4_lw8").removeClass("show_slow");
            $(".page4_lw9").removeClass("show_slow");
            $(".page4_c5_lw8").removeClass("show_slow");
            $(".page4_c5_lw9").removeClass("show_slow");
        old_choose=-1;
        for(var i=0;i<10;i++){
            if(light_list[i]==1){
                $(".page4_bl"+i).css("opacity",0);
                $(".page4_c5_bl"+i).css("opacity",0);
            }
        }
        $("#page4_circle3").attr("style","");
        $("#page4_circle2").attr("style","");
        $("#page4_circle5").attr("style","");
        $("#page4_circle4").attr("style","");
        $("#page4_lt_btn").hide();
        $("#page4_circle_wa").hide();
        $("#page4_c4_cj").hide();
        $("#page4_c1_p").attr("class","page4_c1_p");
        $(".page4_bg1").css("display","inline");
        window.clearInterval(shake_word);
        var p4c1_top=screen_H*0.49-0.25*screen_W;
        var p4c1=$("#page4_circle1");
        p4c1.attr("style","");
        p4c1.css("height",0.5*screen_W);
        p4c1.css("top",p4c1_top);
        var ck_top=screen_H*0.49-2*screen_W;
        //圆圈区域的宽度
        var area_l=screen_W*4;
        var circle_area=$("#circle_area");
        circle_area.css("width",area_l);
        circle_area.css("height",area_l);
        circle_area.css("left",-screen_W*1.5);
        circle_area.css("top",ck_top);
        $("#page4_circle1").attr("class","page4_circle1");
        $("#page4_circle2").attr("class","page4_circle2");
        $("#page4_circle3").attr("class","page4_circle3");
        $("#page4_circle4").attr("class","page4_circle4");
        $("#page4_circle5").attr("class","page4_circle5");
        $(".page4_pw1").show();
        $(".page4_c1_bottoms").show();
        bind_p4c1_btn();
        shakeP4C1Icon();
    }
    //			发送认证请求
    function sendMsg(){
        var p5_input_box=$(".p5_input_box");
        var name=p5_input_box.find("input[name='name']").val().trim();
        if(name==""){
            alert("亲，姓名不可为空哦！");return false;
        }
        var phone=p5_input_box.find("input[name='phone']").val().trim();
        if(phone==""){
            alert("亲，电话不可为空哦！");return false;
        }
        if(!/^1\d{10}$/.test(phone)){
            alert("亲，请输入正确号码！");return false;
        }
        var email=p5_input_box.find("input[name='email']").val().trim();
        if(email==""){
            alert("亲，邮箱不可为空哦！");return false;
        }
        if(!/^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/.test(email)){
            alert("亲，请输入正确邮箱！");return false;
        }
        var daili=p5_input_box.find("input[name='daili']").val().trim();
        if(daili==""){
            alert("亲，代理不可为空哦！");return false;
        }
        $("#page5_content1").hide();
        var page5_content2=$("#page5_content2");
        $(".page5_content").addClass("p5_ct_scale");
        page5_content2.show();
        $(".page5_bottom_btn").show();
    }
    //从认证成功页面再返回查询
    function p5backsearch(){
        var page5=$(".page5");
        var page4=$(".page4");
        page5.css("transform","");
        page5.hide();
        page4.show();
        $("#page4_circle1").attr("onclick","");
        unbind_p4c4bl();
        $(".page4_gtw_box").hide();
        backSearch();
    }
</script>
<script>
    loading(99);
</script>
</body>
</html>