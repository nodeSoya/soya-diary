<?php
return array(
    //'配置项'=>'配置值'
    "AppID"=>"wxe61e2a11ad56ede3",
    "AppSecret"=>"17ff4963e3970e6f468481f2a8533df3",
);