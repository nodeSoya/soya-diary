<?php
namespace WB_Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
    	$this->version=time();
        $config=$this->getconfig();
        $this->assign("wx_config",$config);
        $this->display();
    }
    //    获取config
    function getconfig()
    {
        $admin_model=M("config");
        $admin=$admin_model->where("id=%d",1)->find();
        if (empty($admin['access_token']) || $admin['get_time']+$admin['expire_time']<time()) {
            //get token
            $token = file_get_contents("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".C("AppID")."&secret=".C("AppSecret"));
            $token = json_decode($token,true);
            $access_token = $token['access_token'];
            //get ticket
            $data['access_token'] = $access_token;
            $data['get_time'] = time();
            $data['expire_time'] = $token['expires_in'];
            $admin_model->where("id=%d",1)->save($data);
        }else{
            $access_token = $admin['access_token'];
        }
        if (empty($admin['ticket']) || $admin['ticket_get_time']+$admin['ticket_expire_time']<time()) {
            $ticket_temp = file_get_contents("https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=". $access_token ."&type=jsapi");
            $ticket_res = json_decode($ticket_temp,true);
            $ticket=$ticket_res["ticket"];
            $data['ticket']=$ticket;
            $data["ticket_get_time"]=time();
            $data['ticket_expire_time']=$ticket_res["expires_in"];
            $admin_model->where("id=%d",1)->save($data);
        }
        else
        {
            $ticket=$admin["ticket"];
        }
        //create nonceStr
        $allChar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $nonceStr = "";
        for ($i = 0; $i < 16; $i++) {
            $nonceStr .= substr($allChar, mt_rand(0, strlen($allChar) - 1), 1);
        }

        //create timestamp
        $timestamp = time();

        //get signature
        $tpStr = 'jsapi_ticket='.$ticket.'&noncestr='.$nonceStr.'&timestamp='.$timestamp.'&url=http://'.$_SERVER[HTTP_HOST].$_SERVER[REQUEST_URI];
        $signature = sha1($tpStr);

        $config="wx.config({
				    debug: false,
				    appId: '".C('AppID')."',  //微信的appid需要在公众平台生成
    				    timestamp: '$timestamp', //这是由php部分生成的
    				    nonceStr: '$nonceStr', //这是由php部分生成的
    				    signature: '$signature', //这是由php部分生成的
    				    jsApiList: [
    				    'onMenuShareTimeline',
    				    'onMenuShareAppMessage',
    				    'onMenuShareQQ',
    				    'onMenuShareWeibo',
    				    ]
	    });";
        return $config;
    }
}