var shareurl = 'http://safeiot.com/weibo';
var imgUrl = 'http://safeiot.com/weibo/Weibo/Wb_Home/Public/images/small_logo.jpg';
var title = "微博营销罗盘，等你来探索";
var content = '快来开启微博代理商认证之路，打造最佳微博营销生态系统';
wx.ready(function () {
    wx.onMenuShareAppMessage({
        title: title,
        desc:  content,
        link:  shareurl,
        imgUrl: imgUrl,
        trigger: function (res) {},
        success: function (res) {
            var url="http://safeiot.com/yaocaishen/index.php/YCS_Home/Index/addNum";
            location.href=url;
        },
        cancel: function (res) {},
        fail: function (res) {}
    });
    wx.onMenuShareTimeline({
        title: title,
        link: shareurl,
        imgUrl: imgUrl,
        trigger: function (res) {},
        success: function (res) {
            var url="http://safeiot.com/yaocaishen/index.php/YCS_Home/Index/addNum";
            location.href=url;
        },
        cancel: function (res) {},
        fail: function (res) {}
    });
    wx.onMenuShareQQ({
        title: title,
        desc:  content,
        link:  shareurl,
        imgUrl: imgUrl,
        trigger: function (res) {},
        success: function (res) {},
        cancel: function (res) {},
        fail: function (res) {}
    });
    wx.onMenuShareWeibo({
        title: title,
        desc:  content,
        link:  shareurl,
        imgUrl: imgUrl,
        trigger: function (res) {},
        success: function (res) {},
        cancel: function (res) {},
        fail: function (res) {}
    });
});
